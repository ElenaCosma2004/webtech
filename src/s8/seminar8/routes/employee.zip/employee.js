const Employee = require("../models/employee");

const router = require("express").Router();

// Get all employees
router
  .route("/employees")
  .get(async (req, res) => {
    try {
      const employees = await Employee.findaAll();
      return res.status(200).json(employees);
    } catch (err) {
      return res.status(500).json(err);
    }
  })
  .post(async (req, res) => {
    try {
      const newEmployee = await Employee.create(req.body);
      return res.status(200).json(newEmployee);
    } catch (error) {
      return res.status(500).json(err);
    }
  });

router
  .route("/employees/:id")
  .get(async (req, res) => {
    try {
      const employee = await Employee.findByPk(req.params.id);
      if (employee) {
        return res.status(200).json(employee);
      } else {
        return res
          .status(404)
          .json({
            message: "Employee with id " + req.params.id + " not found",
          });
      }
    } catch (err) {
      return res.status(500).json(err);
    }
  })
  .put(async (req, res) => {
    try {
      const employee = await Employee.findByPk(req.params.id);
      if (employee) {
        return res.status(200).json(await employee.update(req.body));
      } else {
        return res
          .status(404)
          .json({
            message: "Employee with id " + req.params.id + " not found",
          });
      }
    } catch (err) {
      return res.status(500).json(err);
    }
  })
  .delete(async (req, res) => {
    try {
      const employee = await Employee.findByPk(req.params.id);
      if (employee) {
        await employee.destroy();
        return res
          .status(200)
          .json({ message: "Employee with id " + req.params.id + " deleted" });
      } else {
        return res
          .status(404)
          .json({
            message: "Employee with id " + req.params.id + " not found",
          });
      }
    } catch (err) {
      return res.status(500).json(err);
    }
  });
